import React from 'react'

// should receive the countries list data, through the props, to be mapped and rendered
const CountryList = () => {
  return <div>CountryList</div>
}

export default CountryList
