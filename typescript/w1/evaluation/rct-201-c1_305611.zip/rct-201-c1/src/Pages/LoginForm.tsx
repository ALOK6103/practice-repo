import React from 'react'

// should receive the handleSubmit callback function through props
const LoginForm = () => {
  // create a form, to take the user email, and password

  const handleEmailChange = () => {}

  const handlePasswordChange = () => {}

  //  when the user clicks on the Sign In button
  //  call the handleSubmit function, inside this.
  const handleClick = () => {}

  return (
    <div>
      <h1 style={{ textAlign: 'center' }}>Login Form</h1>
      <form></form>
    </div>
  )
}

export default LoginForm
