import React from 'react'

// should receive the addCountryDetails callback function through props
const CountryInput = () => {
  // create a form, to take the country, and capital

  const handleCountryChange = () => {}

  const handleCapitalChange = () => {}

  //  when the user clicks on the Add Country Data button
  //  call the addCountryDetails function, inside this.
  const handleSubmit = () => {}
  return (
    <div>
      <form></form>
    </div>
  )
}

export default CountryInput
