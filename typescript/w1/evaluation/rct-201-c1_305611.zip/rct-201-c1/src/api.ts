// make a successful login request to the reqres.in API
export const loginAPI = () => {};

// make a request to get the list of countries from the db.json file, using JSON server
export const getCountriesAPI = () => {};

//make a request to add a country to the db.json file, using JSON server
export const addCountryDetailsAPI = () => {};
